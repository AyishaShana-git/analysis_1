import uproot
import numpy as np

# Open your ROOT file
file = uproot.open("/home/shana/000001_ana_hist_2025-06-03T_003735Z.root")   

# Get the main analysis tree
tree = file["pdblipana/BlipRecoAlg/matchtree"]

# Read branches
qA = tree["qA"].array(library="np")
dt = tree["dt"].array(library="np")


# Event selection (cuts)
mask = (qA > 100) & (dt < 10)

print("Total entries:", len(qA))
print("Selected events:", mask.sum())


