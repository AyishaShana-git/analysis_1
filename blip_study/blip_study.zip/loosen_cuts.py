import uproot
import awkward as ak
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# Open ROOT file
# -----------------------------
file = uproot.open("/home/shana/000001_ana_hist_2025-06-03T_003735Z.root")
tree = file["pdblipana/anatree"]

# -----------------------------
# Read blip-level variables
# -----------------------------
blip_energy = tree["blip_energy"].array()
blip_charge = tree["blip_charge"].array()
blip_size   = tree["blip_size"].array()

# -----------------------------
# Loosened selection
# (This is temporary to demonstrate the pipeline)
# -----------------------------
# Example: allow more blips to survive
blip_mask = (
    (blip_energy > 50) &      # lower min energy
    (blip_energy < 500) &     # higher max energy
    (blip_charge > 0) &       # remove strict charge cut
    (blip_size >= 1)           # allow small clusters
)

blip_energy_sel = blip_energy[blip_mask]

# -----------------------------
# Sum blip energies per event → event_visible_energy
# -----------------------------
event_visible_energy = ak.sum(blip_energy_sel, axis=1)

# Remove events with zero energy
event_visible_energy = event_visible_energy[event_visible_energy > 0]

# Convert to NumPy for plotting
event_visible_energy = ak.to_numpy(event_visible_energy)

# -----------------------------
# Plot visible energy histogram
# -----------------------------
plt.figure(figsize=(8,6))
plt.hist(event_visible_energy, bins=50, range=(0, 600), histtype='step', color='blue', label="Events")
plt.axvline(236, color='red', linestyle='--', label="KDAR νµ expected energy")
plt.xlabel("Event visible energy [MeV]")
plt.ylabel("Number of events")
plt.title("KDAR νµ energy proxy (loosened cuts)")
plt.legend()
plt.show()
